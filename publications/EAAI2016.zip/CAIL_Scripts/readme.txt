1. Please install .Net framework (3.5 or later) for using the CAIL tool
2. The paper link: 

http://www.sciencedirect.com/science/article/pii/S0952197616301804

Please do not hesitate to contact me if you have any question.

Muhammad Yousefnezhad,
College of Computer Science and Technology,
Nanjing University of Aeronautics and Astronautics,
Email: myousefnezhad@outlook.com,
Website: https://myousefnezhad.github.io/